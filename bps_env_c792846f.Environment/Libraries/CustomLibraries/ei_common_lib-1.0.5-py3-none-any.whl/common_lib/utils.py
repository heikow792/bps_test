'''
Description: This file contains the common functions used in notebooks.
'''

import ast
from functools import reduce
import json
from datetime import datetime
from sys import exception
import pyodbc
import struct
import sqlalchemy
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from delta import DeltaTable
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import coalesce, col, lit, when
from pyspark.sql.types import IntegerType, StringType, DecimalType, DateType, TimestampType
from pyspark.sql.utils import AnalysisException
from pyspark.sql.column import Column
from pyspark.sql import functions as F

from common_lib.constants import LOG_FILE_PATH
from common_lib.logger.dataframe_logger import DataFrameLogger
from common_lib.exceptions import (
    DeltaTableNotFoundException,
    DuplicateEntriesInTable,
    WaterMarkColumnsNotFound,
    RecordCountMismatchException,
    CubeConfigValidationFailed
)


def create_delta_file_in_gold(
        spark: SparkSession,
        delta_file_path: str,
        silver_df: DataFrame,
        logger: DataFrameLogger,
        create_empty_df: bool = False,
        is_fact_df:bool = False) -> bool:
    """
    Check if delta file exists, if not, create it.

    Parameters:
    :param spark: SparkSession
    :param delta_file_path: path where delta file is created
    :param silver_df: silver DataFrame
    :param logger: logger object

    Returns:
    :return: True if delta file is created, False otherwise
    """
    try:
        # If the Gold layer doesn't exist we have to create it before we proceed with the rest
        if not DeltaTable.isDeltaTable(spark, delta_file_path):
            # Define the schema for the gold DataFrame, dropping '_Delete' and adding 'Key'
            if '_Delete' in silver_df.columns:
                gold_schema = silver_df.drop('_Delete').schema
            else:
                gold_schema = silver_df.schema

            if not is_fact_df and 'Key' not in gold_schema.names:
                gold_schema.add("Key", IntegerType(), False)

            # check if we need to create an empty DataFrame
            if create_empty_df:
                logger.info("Creating empty delta file")
                gold_dim = spark.createDataFrame([], schema=gold_schema)
            else:
                # Create a DataFrame with a single row with Key = -1 and other columns as null
                # None for all columns except for 'Key'
                logger.info("Creating delta file")

                if is_fact_df:
                    default_row = [(None,) * (len(gold_schema) - 1)]
                else:
                    default_row = [(None,) * (len(gold_schema) - 1) + (-1,)]

                gold_dim = spark.createDataFrame(default_row, schema=gold_schema)

            # Write the DataFrame with the default row to the gold table
            gold_dim.write.format('delta').mode('overwrite').save(delta_file_path)
            logger.info("Delta file created in gold layer at " + delta_file_path)

            # Return True to indicate that the delta file was created
            return True

        # Return False to indicate that the delta file already exists
        logger.info("Delta file already exists in gold layer at " + delta_file_path)
        return False

    except Exception as exception:
        # Log the exception message & Raise the exception again to propagate it
        logger.error("Exception occurred: " + str(exception))
        logger.save_logs(spark)
        raise exception

def create_delta_file_in_silver(
        spark: SparkSession,
        delta_file_path: str,
        df: DataFrame,
        logger: DataFrameLogger,
        create_empty_df: bool = False) -> bool:
    """
    Check if delta file exists in silver layer, if not, create it.

    Parameters:
    :param spark: SparkSession
    :param delta_file_path: path where delta file is created
    :param df: DataFrame
    :param logger: logger object
    :param create_empty_df: flag to determine if an empty DataFrame should be created

    Returns:
    :return: True if delta file is created, False otherwise
    """
    try:
        # Check if the Silver layer delta table exists
        if not DeltaTable.isDeltaTable(spark, delta_file_path):
            # Define the schema for the silver DataFrame
            silver_schema = df.schema

            # check if we need to create an empty DataFrame
            if create_empty_df:
                logger.info("Creating empty delta file")
                silver_table = spark.createDataFrame([], schema=silver_schema)
            else:
                # Create a DataFrame with a single row with null values
                logger.info("Creating delta file")
                default_row = [(None,) * len(silver_schema)]
                silver_table = spark.createDataFrame(default_row, schema=silver_schema)

            # Write the DataFrame with the default row to the silver table
            silver_table.write.format('delta').mode('overwrite').save(delta_file_path)
            logger.info("Delta file created in silver layer at " + delta_file_path)

            # Return True to indicate that the delta file was created
            return True

        # Return False to indicate that the delta file already exists
        logger.info("Delta file already exists in silver layer at " + delta_file_path)
        return False

    except Exception as e:
        logger.error(f"Error creating delta file in silver layer: {str(e)}")
        logger.save_logs(spark)
        raise

def get_log_file_path(silver_lakehouse_path: str) -> str:
    """
    Get the log file path.
    :return: log file path
    """

    # get date in string format
    date = datetime.today().strftime('%Y-%m-%d')
    silver_lakehouse_files_path = silver_lakehouse_path.replace('Tables/', LOG_FILE_PATH)
    return f'{silver_lakehouse_files_path}{date}/'

# Function to apply join conditions from a list of tuples
def apply_join_conditions(
    fact_name: str,
    dimension_name: str,
    fact_df: DataFrame,
    dimension_df: DataFrame,
    join_conditions: str,
    sk_column: str,
    extra_dim_cols: list,
    logger: DataFrameLogger) -> DataFrame:
    """
    Apply join conditions to perform a left join between the fact and dimension DataFrames.

    Parameters:
    :param dimension_name: name of the dimension DataFrame
    :param fact_df: fact DataFrame
    :param dimension_df: dimension DataFrame
    :param join_conditions: string representation of a list of tuples specifying the join conditions
    :param sk_column: name of the column to store the surrogate key

    Returns:
    :return: joined DataFrame

    Raises:
    :raises ValueError: if the join conditions are not in the correct format
    :raises AnalysisException: if the join conditions are not in the correct format
    """
    try:
        # Convert string to list of tuples
        join_conditions = ast.literal_eval(join_conditions)

        # Always include the _SystemName join condition
        join_conditions.append(('_SystemName', '_SystemName', '=='))

        # Apply special conditions
        dimension_df = apply_special_conditions(
            dimension_name = dimension_name,
            dimension_df = dimension_df,
            join_conditions = join_conditions,
            logger = logger)

        dimension_df = apply_fact_based_special_conditions(
            fact_name = fact_name,
            dimension_name = dimension_name,
            dimension_df = dimension_df,
            join_conditions = join_conditions,
            logger = logger)

        # Alias both DataFrames
        fact_df_alias = fact_df.alias("fact")
        dim_df_alias = dimension_df.alias("dim")

        complete_condition = None

        # Define a default value to replace nulls
        default_value = lit("NULL_VALUE")

        complete_condition = get_complete_join_condition(
            join_conditions,
            complete_condition,
            default_value)

        # drop the extra columns from the fact dataframe
        fact_df_alias = fact_df_alias.drop(*extra_dim_cols)

        # Perform the join
        fact_df = fact_df_alias.join(dim_df_alias, complete_condition, 'left')

        select_column_list = ["fact.*"]
        for column in extra_dim_cols:
            column_name = f"dim.{column}"
            select_column_list.append(column_name)

        # Select and rename the key column
        fact_df = fact_df.select(*select_column_list, coalesce(col("dim.Key"), lit(-1)).alias(sk_column))
        return fact_df

    except (ValueError, AnalysisException) as exception:
        # Log the exception message & Raise the exception again to propagate it
        logger.error("Exception occurred: " + str(exception))
        raise exception

def get_complete_join_condition(
    join_conditions,
    complete_condition,
    default_value):
    """
    Constructs a complete join condition based on the provided join conditions.

    This function iterates over the provided join conditions
    and constructs a complete join condition.
    The join condition is constructed based on the condition type (==, >=, <=).
    If the condition type is not supported, a ValueError is raised.

    Parameters:
    join_conditions (List[Tuple[str, str, str]]): A list of tuples, where each tuple contains a fact
    column name, a dimension column name, and a condition type.
    complete_condition (Column): The initial complete condition. If None, the first condition will
    be used as the initial complete condition.
    default_value (Any): The default value used in the coalesce function when the
    condition type is ==.

    Returns:
    Column: The complete join condition.

    Raises:
    ValueError: If an unsupported condition type is provided.
    """

    for fact_col, dim_col, condition_type in join_conditions:
        if condition_type == "==":
            current_condition = coalesce(col(f"fact.{fact_col}"), default_value) == \
                coalesce(col(f"dim.{dim_col}"), default_value)
        elif condition_type == ">=":
            current_condition = col(f"fact.{fact_col}") >= col(f"dim.{dim_col}")
        elif condition_type == "<=":
            current_condition = col(f"fact.{fact_col}") <= col(f"dim.{dim_col}")
        else:
            raise ValueError(f"Unsupported join condition type: {condition_type}")

        # Combine conditions
        if complete_condition is None:
            complete_condition = current_condition
        else:
            complete_condition &= current_condition
    return complete_condition

def apply_special_conditions(
    dimension_name: str,
    dimension_df:DataFrame,
    join_conditions: str,
    logger: DataFrameLogger) -> DataFrame:
    """
    Applies special conditions to a DataFrame based on the dimension name.

    This function applies special conditions to the input DataFrame `dimension_df`
    based on the dimension name `dimension_name`.
    If the dimension name is 'I_FISCALPERIODFORVARIANT',
    it filters out rows where 'ISSPECIALPERIOD' is null.
    If the dimension name is 'I_PROFITCENTER', 'I_COSTCENTER', or 'I_COSTCENTERACTIVITYTYPE',
    it finds distinct rows based on the primary keys and 'Key' column.

    Parameters:
    dimension_name (str): The name of the dimension.
    dimension_df (DataFrame): The input DataFrame to which the special conditions are applied.
    join_conditions (str): The join conditions.
    logger (DataFrameLogger): The logger used for logging information.

    Returns:
    DataFrame: The DataFrame after applying the special conditions.
    """

    # Eliminating special periods for I_FISCALPERIODFORVARIANT
    logger.debug(f"Checking special conditions for dimension: {dimension_name}")
    if dimension_name == 'I_FISCALPERIODFORVARIANT':
        dimension_df = dimension_df.filter((col('ISSPECIALPERIOD').isNull()) | (col('ISSPECIALPERIOD') == ""))
        logger.info(f"Special condition applied for dimension: {dimension_name}")

    # If the dimension is I_PROFITCENTER or I_COSTCENTER, find distinct based on the primary key
    if dimension_name in ['I_PROFITCENTER', 'I_COSTCENTER', 'I_COSTCENTERACTIVITYTYPE']:
        # Extract primary keys from join conditions
        logger.debug("Calculating distinct values")

        primary_keys = []
        for fact_col, dim_col, cond_type in join_conditions:
            if cond_type == '==' and dim_col != 'VALIDITYENDDATE':
                primary_keys.append(dim_col)

        # Apply distinct operation on primary keys and 'Key' column
        dimension_df = dimension_df.dropDuplicates(primary_keys + ['Key'])
        logger.debug(f"Number of rows {dimension_df.count()}")
        logger.info(f"Special condition applied for dimension: {dimension_name}")

    return dimension_df

def apply_fact_based_special_conditions(
    fact_name: str,
    dimension_name: str,
    dimension_df:DataFrame,
    join_conditions: str,
    logger: DataFrameLogger) -> DataFrame:
    """
    Applies special conditions to a DataFrame based on the dimension name.

    This function applies special conditions to the input DataFrame `dimension_df`
    based on the dimension name `dimension_name`.
    If the dimension name is 'I_PURCHASINGDOCUMENTTYPE', and the fact name is 'C_PURCHASEORDERDEX' or 'C_PURCHASEORDERITEMDEX',
    it filters out rows where 'PURCHASINGDOCUMENTCATEGORY' is not 'F'.

    Parameters:
    dimension_name (str): The name of the dimension.
    dimension_df (DataFrame): The input DataFrame to which the special conditions are applied.
    join_conditions (str): The join conditions.
    logger (DataFrameLogger): The logger used for logging information.

    Returns:
    DataFrame: The DataFrame after applying the special conditions.
    """
    facts_with_special_cond = set(["C_PURCHASEORDERDEX", "C_PURCHASEORDERITEMDEX", "C_PURCHASEREQUISITIONITEMDEX"])
    # Eliminating PURCHASINGDOCUMENTCATEGORY 'F' for I_PURCHASINGDOCUMENTTYPE
    logger.info(f"Checking special conditions for dimension: {dimension_name}")
    if fact_name in facts_with_special_cond and dimension_name == "I_PURCHASINGDOCUMENTTYPE":
        dimension_df = dimension_df.filter(col('PURCHASINGDOCUMENTCATEGORY') == "F")

    return dimension_df

# Check the number of rows to be processed
def get_iso_language_expression() -> Column:
    """
    Maps language codes to their ISO equivalents (bidirectional).
    - Converts SAP codes to ISO codes (e.g., 'a' → 'AF')
    - Preserves ISO codes if already in ISO format (e.g., 'AF' → 'AF')
    """
    # SAP to ISO mapping (reverse of ISO to SAP)
    sap_to_iso = {
        'a': 'AF', '0': 'SR', '1': 'ZH', '2': 'TH', '3': 'KO', '4': 'RO', '5': 'SL',
        '6': 'HR', '7': 'MS', '8': 'UK', '9': 'ET', 'A': 'AR', 'B': 'HE', 'C': 'CS',
        'D': 'DE', 'E': 'EN', 'F': 'FR', 'G': 'EL', 'H': 'HU', 'I': 'IT', 'J': 'JA',
        'K': 'DA', 'L': 'PL', 'M': 'ZF', 'N': 'NL', 'O': 'NO', 'P': 'PT', 'Q': 'SK',
        'R': 'RU', 'S': 'ES', 'T': 'TR', 'U': 'FI', 'V': 'SV', 'W': 'BG', 'X': 'LT',
        'Y': 'LV', 'Z': 'Z1', 'b': 'IS', 'c': 'CA', 'd': 'SH', 'i': 'ID', '묩': 'HI',
        '뱋': 'KK', '쁩': 'VI'
    }

    # Add identity mappings for ISO codes (bidirectional: ISO code → same ISO code)
    iso_mapping = {value: value for value in sap_to_iso.values()}
    sap_to_iso.update(iso_mapping)

    # Flatten to key-value pairs for create_map
    pairs = [item for pair in sap_to_iso.items() for item in pair]

    # Create a lookup map and get the value, default to None if not found
    return F.create_map([lit(x) for x in pairs]).getItem(col("LANGUAGE"))

# Function to connect to Azure SQL Database using connection string.
def connect_to_azure_sql_db(connection_string):
    """
    Connect to Azure SQL Database using the provided connection string and return the
    connection object.

    This function uses the provided connection string to connect to an Azure SQL Database
    and returns the connection object. If the connection is successful, the function prints
    "Connection successful". If the connection fails, the function prints "Connection failed"
    and the exception message.

    Parameters:
    connection_string (str): The connection string used to connect to the Azure SQL Database.

    Returns:
    pyodbc.Connection: The connection object used to interact with the Azure SQL Database

    Raises:
    Exception: If the connection fails, the function raises an exception with the error message.
    """
    try:
        conn = pyodbc.connect(connection_string)
        print("Connection successful")
        return conn
    except pyodbc.Error as e:
        print("Connection failed")
        print(e)
        raise

# function that takes a connection object and returns a list of all the tables in the database
def execute_sql_query(conn, query):
    """
    Executes an SQL query using the provided connection object and query string, and returns
    a list of all tables in the database.

    This function executes the provided SQL query using the connection object and query string,
    and returns a list of all tables in the database. The function prints "Query executed
    successfully" if the query is executed successfully. If the query fails, the function prints
    "Query execution failed" and the exception message.

    Parameters:
    conn (pyodbc.Connection): The connection object used to interact with the database.
    query (str): The SQL query string to be executed.

    Returns:
    list: A list of all tables in the database.
    """
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        result = cursor.fetchall()
        return result
    except pyodbc.Error as e:
        print(f"Query execution failed for query {query}")
        print(e)
        raise

# function that parses the output from the sql query result.
def parse_query_output(result) -> str:
    """
    Parses the output from an SQL query result and returns a string representation of the result.

    This function takes the output from an SQL query result and returns a string representation
    of the result. The function concatenates the values in the result and returns the string
    representation.

    Parameters:
    result (list): The output from an SQL query result.

    Returns:
    str: A string representation of the result.
    """
    p_lookup_output = ""
    for i in result:
        p_lookup_output += i[0]
    return p_lookup_output

def compare_time(start, end, approach_name=None):
    """
    Compare the time taken to execute an approach and print the duration.

    This function takes the start and end times of an approach, calculates the duration,
    and prints the duration in seconds. If an approach name is provided, the function also
    prints the approach name.

    Parameters:
    start (float): The start time of the approach.
    end (float): The end time of the approach.

    Keyword Arguments:
    approach_name (str): The name of the approach (default: None).
    """
    duration = end - start
    if approach_name is not None:
        print(f"Time taken to perform merge operation is {duration} seconds")

def get_odpname(cdsviewname, cds_odp_map):
    """
    Get the ODPName for a specified CDSViewName.

    This function gets the ODPName for the specified CDSViewName, and returns the
    ODPName.

    Parameters:
    cdsviewname (str): The name of the CDS view.
    cds_odp_map (str): The dictionary containing a mapping from CDSViewName to ODPName.

    Returns:
    str: The ODPName for the specified CDSViewName.
    """
    for item in cds_odp_map:
        # Return ODPName for specified CDSViewName
        if item['CDSViewName'] == cdsviewname:
            print(f"For CDSViewName: {item['CDSViewName']}, ODPName: {item['ODPName']}")
            return item['ODPName']
    return None

def check_if_table_exists(
        spark: SparkSession,
        delta_file_path: str,
        logger: DataFrameLogger) -> bool:
    """Function to check if the delta table exists.

    Args:
        spark (SparkSession): spark session.
        delta_file_path (str): delta file path.
        logger (DataFrameLogger): logger object.

    Returns:
        bool: return true if table exists, false otherwise.
    """
    try:
        if not DeltaTable.isDeltaTable(spark, delta_file_path):
            return False
        return True

    except Exception:
        # Log the exception message & Raise the exception again to propagate it
        logger.error(f"Exception occurred when checking if table exists file path {delta_file_path}")
        return False

def parse_gold_lakehouse_path(lakehouse_path: str) -> str:
    """Function to parse the gold lakehouse path.

    Args:
        lakehouse_path (str): lakehouse path.

    Returns:
        str: return gold lakehouse path.
    """
    if lakehouse_path is None or len(lakehouse_path) == 0:
        # TODO: raise an exception
        return None


    path_contents = lakehouse_path.split('/')
    workspace = path_contents[2]
    lakehouse_name = path_contents[3]

    if len(workspace) == 0 or len(lakehouse_name) == 0:
        # TODO: raise an exception
        return None

    return f"abfss://{workspace}/{lakehouse_name}/Tables/"

def generate_reprocess_condition(column_list):
    """Function to generate reprocess condition for the given column list.

    Args:
        column_list (list): list of columns.

    Returns:
        Column: return the reprocess condition.
    """
    complete_condition = None
    key_col = column_list[-1]
    column_list = list(set(column_list[0:len(column_list)-1]))

    for column in column_list[0:len(column_list)]:
        current_condition = col(f"{column}").isNotNull()
        # print(current_condition)

        # Combine conditions
        if complete_condition is None:
            complete_condition = current_condition
        else:
            complete_condition &= current_condition

    key_col_condition = col(f"{key_col}").isin('-1')
    # Combine conditions
    if complete_condition is None:
        complete_condition = key_col_condition
    else:
        complete_condition &= key_col_condition

    return complete_condition

def get_reprocess_condition(configuration, silver_df_columns: set):
    """Function to generate reprocess conditions.

    Args:
        config (str): reprocess configuration.
        silver_df_columns (set): set of columns in silver dataframe.

    Returns:
        list: return the reprocess conditions.
    """

    reprocess_conditions = []
    for config in configuration:
        join_conditions = config["JoinCondition"]
        sk_column = config["SKColumn"]

        if sk_column not in silver_df_columns:
            print(f"Skiping Reprocess condition, {sk_column} not available in Silver Dataframe.")
            continue

        # Convert string to list of tuples
        join_conditions = ast.literal_eval(join_conditions)
        column_list = []
        for condition in join_conditions:
            column_list.append(condition[0])

        column_list.append(sk_column)
        expr = generate_reprocess_condition(column_list)
        reprocess_conditions.append(expr)
    return reprocess_conditions

def parse_lakehouse_details(lakehouse_details, system_name: str = None):
    """
    Parse Microsoft Fabric Lakehouse details and extract relevant paths.

    When system_name is provided and the lakehouse has schemas enabled
    (defaultSchema property exists), the tables path includes the system_name
    as a schema prefix.

    Parameters:
    :param lakehouse_details: Lakehouse details dictionary from Fabric API
    :param system_name: Optional source system name to use as schema in the tables path

    Returns:
        dict: Dictionary containing parsed lakehouse paths with keys:
            - tables_path: Path to Tables directory (with schema if enabled and system_name provided)
            - files_path: Path to Files directory
            - logs_path: Path to Logs directory
            - sql_analytics_endpoint: SQL Analytics endpoint connection string
    Raises:
        KeyError: If required properties are missing from lakehouse_details
        Exception: For other parsing errors
    """
    try:
        sql_analytics_endpoint = lakehouse_details['properties']['sqlEndpointProperties']['connectionString']
        base_path = lakehouse_details['properties']['abfsPath']

        # Check if the lakehouse has schemas enabled and system_name is provided
        default_schema = lakehouse_details.get('properties', {}).get('defaultSchema', None)

        if default_schema is not None:
            if system_name is None:
                tables_path = f"{base_path}/Tables/dbo/"
            else:
                tables_path = f"{base_path}/Tables/{system_name}/"
        else:
            tables_path = f"{base_path}/Tables/"

        lakehouse_info = {
            'tables_path': tables_path,
            'files_path': base_path + '/Files/',
            'logs_path': base_path + '/Files/Logs/',
            'sql_analytics_endpoint': sql_analytics_endpoint
        }
        return lakehouse_info
    except KeyError as e:
        print(f"Missing required key in lakehouse details: {e}")
        raise
    except Exception as e:
        print(f"Error parsing lakehouse details: {e}")
        raise

def execute_sql_query_fsql(conn, query):
    """
    Execute an SQL query using the provided connection object.

    Parameters:
    :param conn: SQLAlchemy connection object
    :param query: SQL query string to be executed

    Returns:
    :return: Results of the query execution

    Raises:
    :raises SQLAlchemyError: If the query execution fails
    """
    try:
        result = conn.execute(text(query))
        results = result.fetchall()
        print("Query executed successfully")
        return results
    except SQLAlchemyError as e:
        print(f"Query execution failed for query: {query}")
        print(e)
        raise

def parse_mirror_db_details(database: dict, db_display_name: str) -> dict:
    """
    Parse mirror database information and convert OneLake path to abfss format.

    This function extracts database properties from a Fabric mirrored database object
    and converts the OneLake path to abfss format for use with Spark/Delta operations.

    Parameters:
    :param database: Database dictionary from Fabric REST API response
    :param db_display_name: Display name of the database

    Returns:
    :return: Dictionary with parsed database properties including:
        - database_name: Display name of the database
        - database_id: Unique database ID
        - oneLakeTablesPath: Original OneLake path (https format)
        - abfssTablesPath: Converted abfss format path
        - sql_connection_string: SQL endpoint connection string
    """
    try:
        oneLake_path = database['properties']['oneLakeTablesPath']

        # Convert to abfss format
        # Example input: https://<domain>/<workspace_id>/<database_id>/Tables/
        # Desired: abfss://<workspace_id>@<domain>/<database_id>/Tables/

        parts = oneLake_path.replace("https://", "").split("/")
        domain = parts[0]
        workspace_id = parts[1]
        database_id = parts[2]
        suffix_path = "/".join(parts[3:])

        abfss_path = f"abfss://{workspace_id}@{domain}/{database_id}/{suffix_path}/"

        properties = {
            'database_name': db_display_name,
            'database_id': database['id'],
            'oneLakeTablesPath': oneLake_path,
            'abfssTablesPath': abfss_path,
            'sql_connection_string': database['properties']['sqlEndpointProperties']['connectionString']
        }
        return properties
    except (KeyError, IndexError) as e:
        error_message = f"Failed to parse mirror database details: {str(e)}"
        print(error_message)
        raise Exception(error_message) from e

def connect_to_fabric_sql_db(connection_string: str, token: str):
    """
    Create and return a database connection to Fabric SQL Database.

    This function creates a SQLAlchemy engine configured to use token-based authentication
    for connecting to Fabric SQL Database.

    Parameters:
    :param connection_string: The SQL connection string for the target database
    :param token: The Microsoft Entra token for authentication (raw token string)

    Returns:
    :return: SQLAlchemy connection object

    Raises:
    :raises Exception: If connection fails
    """
    # Encode token for SQL Server authentication
    token_encoded = token.encode("UTF-16-LE")
    token_struct = struct.pack(f'<I{len(token_encoded)}s', len(token_encoded), token_encoded)
    SQL_COPT_SS_ACCESS_TOKEN = 1256

    # Create SQLAlchemy engine with token-based authentication
    engine = sqlalchemy.create_engine(
        "mssql+pyodbc://",
        creator=lambda: pyodbc.connect(
            connection_string,
            attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct}
        )
    )

    # Return a connection from the engine
    connection = engine.connect()
    return connection

def standardize_column_names(
    df: DataFrame,
    exclude_columns: list = None) -> DataFrame:
    """
    Standardize DataFrame column names by converting to uppercase, with option to exclude specific columns.

    This function renames all columns to uppercase except those specified in the exclusion list.
    Default excluded columns are always preserved, with additional columns appended if provided.
    Useful for data standardization while preserving system columns unchanged.

    Parameters:
    :param df: Input DataFrame to transform
    :param exclude_columns: List of additional column names to exclude from uppercase conversion (appended to defaults)

    Returns:
    :return: DataFrame with standardized column names
    """
    # Start with default excluded columns
    default_exclude_columns = ["_SystemName", "_UpdateTimeStamp", "_Delete", "_change_type"]

    # Append any customer-provided columns
    if exclude_columns is not None:
        default_exclude_columns.extend(exclude_columns)

    return df.select([
        F.col(c).alias(c if c in default_exclude_columns else c.upper())
        for c in df.columns
    ])

def get_max_timestamp(df, logger, timestamp_column="_UpdateTimeStamp", system_name=None):
    """
    Get the maximum timestamp from a DataFrame for the specified column.

    Args:
        df: Spark DataFrame to process
        logger: Logger object for logging
        timestamp_column (str): Name of the timestamp column to check (default: '_UpdateTimeStamp')
        system_name (str): Optional system name to filter by _SystemName column

    Returns:
        timestamp: Maximum timestamp value if data exists and column is present, None otherwise
    """
    
    if timestamp_column not in df.columns:
        logger.warning(f"Timestamp column '{timestamp_column}' not found in DataFrame schema")
        return None

    if system_name and "_SystemName" in df.columns:
        df = df.filter(col("_SystemName") == system_name)

    if df.limit(1).count() == 0:
        logger.info(f"DataFrame is empty, no timestamp to retrieve")
        return None

    try:
        logger.info(f"Calculating maximum timestamp from column '{timestamp_column}'")
        max_time_stamp_row = df.agg(F.max(col(timestamp_column)).alias("maxTimestamp")).collect()[0]
        max_timestamp_value = max_time_stamp_row['maxTimestamp']
        logger.info(f"Maximum timestamp value: {max_timestamp_value}")
        return max_timestamp_value
    except Exception as e:
        error_message = f"Error calculating max timestamp from column '{timestamp_column}': {str(e)}"
        logger.error(error_message)
        return None

def get_sap_language_expression(col_name) -> Column:
    """
    Maps language codes to their SAP equivalents (bidirectional).
    - Converts ISO language codes to SAP codes (e.g., 'AF' → 'a')
    - Preserves SAP codes if already in SAP format (e.g., 'a' → 'a')
    """
    # ISO to SAP mapping
    iso_to_sap = {
        'AF': 'a', 'SR': '0', 'ZH': '1', 'TH': '2', 'KO': '3', 'RO': '4', 'SL': '5',
        'HR': '6', 'MS': '7', 'UK': '8', 'ET': '9', 'AR': 'A', 'HE': 'B', 'CS': 'C',
        'DE': 'D', 'EN': 'E', 'FR': 'F', 'EL': 'G', 'HU': 'H', 'IT': 'I', 'JA': 'J',
        'DA': 'K', 'PL': 'L', 'ZF': 'M', 'NL': 'N', 'NO': 'O', 'PT': 'P', 'SK': 'Q',
        'RU': 'R', 'ES': 'S', 'TR': 'T', 'FI': 'U', 'SV': 'V', 'BG': 'W', 'LT': 'X',
        'LV': 'Y', 'Z1': 'Z', 'IS': 'b', 'CA': 'c', 'SH': 'd', 'ID': 'i', 'HI': '묩',
        'KK': '뱋', 'VI': '쁩'
    }

    # Add identity mappings for SAP codes (bidirectional: SAP code → same SAP code)
    sap_mapping = {value: value for value in iso_to_sap.values()}
    iso_to_sap.update(sap_mapping)

    # Flatten to key-value pairs for create_map
    pairs = [item for pair in iso_to_sap.items() for item in pair]

    # Create a lookup map and get the value, default to None if not found
    mapping_expr = F.create_map([F.lit(x) for x in pairs])

    return F.coalesce(
        mapping_expr[F.col(col_name)],
        col(col_name)
    )

def remove_unused_columns(df: DataFrame, logger=None) -> DataFrame:
    """
    Remove unused columns from a Spark DataFrame.

    This function removes columns that are not needed in the data processing pipeline.
    Currently hardcoded to remove the 'MANDT' column (SAP client field).

    Parameters:
    :param df: Input Spark DataFrame to process
    :param logger: Optional logger object for logging information

    Returns:
    :return: DataFrame with unused columns removed
    """
    # Hardcoded columns to remove
    unused_columns = ["MANDT"]

    # Filter columns that exist in the DataFrame
    columns_to_remove = [column_name for column_name in unused_columns if column_name in df.columns]

    if not columns_to_remove:
        if logger:
            logger.info("No unused columns found in DataFrame")
        return df

    if logger:
        logger.info(f"Removing unused columns: {columns_to_remove}")

    # Drop the unused columns
    return df.drop(*columns_to_remove)

def detect_date_format_efficient(df, col_name, sample_size=200):
    formats = [
        "yyyy-MM-dd",
        "yyyy-dd-MM",
        "yyyyMMdd",
        "dd-MM-yyyy",
        "MM-dd-yyyy",
        "dd/MM/yyyy",
        "MM/dd/yyyy"
    ]
    # Sample once
    sample_df = df.select(F.col(col_name).cast("string")).dropna().limit(sample_size)
    if sample_df.count() == 0:
        return None

    # Build aggregation expressions (single pass)
    agg_exprs = [
        F.sum(
            F.when(F.to_date(F.col(col_name), fmt).isNotNull(), 1).otherwise(0)
        ).alias(fmt)
        for fmt in formats
    ]

    result = sample_df.agg(*agg_exprs).collect()[0].asDict()

    # Pick best format
    best_format = max(result, key=result.get)
    if result[best_format] == 0:
        return None
    return best_format

def apply_data_types(
    input_df,
    table_metadata,
    sap_data_type_mapping,
    logger):

    # load schema into object
    schema_list = table_metadata
    # get columns for input_df
    col_set = set(input_df.columns)

    # Use a for loop to create StructField objects
    for field in schema_list:
        field = json.loads(field)
        column_name = field['fieldName']
        if field['dataType'] in sap_data_type_mapping:
            data_type = sap_data_type_mapping[field['dataType']]

            # if datatype is decimal, fix the length and decimal fields
            if isinstance(data_type, DecimalType):
                data_type = DecimalType(field['length'], field['decimals'])
        else:
            data_type = StringType()

        if column_name in col_set and data_type != StringType():
            logger.info(f"current data type for column {column_name} is {input_df.schema[column_name].dataType}, target data type is {data_type}")
            current_dtype = input_df.schema[column_name].dataType
            if current_dtype == data_type:
                logger.info(f"Column {column_name} is already of type {data_type}, skipping conversion")
                continue

            logger.debug(f"Casting column {column_name} to data type {data_type}")

            if field['dataType'] == 'NUMC':
                input_df = input_df.withColumn(column_name, F.when(F.col(column_name) == "00000000", F.lit(None)).otherwise(F.col(column_name)))
            if field['dataType'] == 'DATS':
                current_dtype = input_df.schema[column_name].dataType
                if isinstance(current_dtype, (DateType, TimestampType)):
                    logger.info(f"Column {column_name} is already of type {current_dtype}, skipping DATS conversion")
                    continue
                detected_format = detect_date_format_efficient(input_df, column_name)
                if detected_format is None:
                    logger.warning(f"Could not detect date format for column {column_name}")
                    continue
                logger.info(f"Detected date format for column {column_name} is {detected_format}")
                input_df = input_df.withColumn(column_name, F.to_date(input_df[column_name], detected_format))
            else:
                input_df = input_df.withColumn(column_name, input_df[column_name].cast(data_type))
    return input_df

def validate_delta_table(
    spark: SparkSession,
    table_path: str,
    p_CDSViewName: str,
    logger: DataFrameLogger) -> None:
    """
    Validate that a path is a valid Delta table.

    Checks if the given path is a valid Delta table and if it exists.
    Raises appropriate exceptions if validation fails.

    Parameters:
    :param spark: SparkSession
    :param table_path: Base path to the table location
    :param p_CDSViewName: CDS view name appended to the base path
    :param logger: Logger object for logging

    Raises:
    :raises DeltaTableNotFoundException: If the resolved table path does not point to a valid Delta table
    """
    complete_table_path = table_path + p_CDSViewName
    # Use existing function to check if table exists and is a delta table
    if not check_if_table_exists(spark, complete_table_path, logger):
        logger.error(f"Table {p_CDSViewName} not found or invalid at path '{complete_table_path}'")
        logger.save_logs(spark=spark)
        raise DeltaTableNotFoundException(complete_table_path)

def validate_mirrored_delta_table(
    spark: SparkSession,
    table_path: str,
    p_CDSViewName: str,
    p_ODPName: str,
    logger: DataFrameLogger) -> None:
    """
    Validate that a path is a valid Delta table.

    Checks if the given path is a valid Delta table and if it exists.
    Raises appropriate exceptions if validation fails.

    Parameters:
    :param spark: SparkSession
    :param table_path: Base path to the table location
    :param p_CDSViewName: CDS view name appended to the base path
    :param p_ODPName: ODP name appended to the base path
    :param logger: Logger object for logging

    Raises:
    :raises DeltaTableNotFoundException: If the resolved table path does not point to a valid Delta table
    """
    complete_table_path = table_path + p_CDSViewName
    complete_odp_table_path = table_path + p_ODPName
    # Use existing function to check if table exists and is a delta table
    cds_view_exists = check_if_table_exists(spark, complete_table_path, logger)
    odp_view_exists = check_if_table_exists(spark, complete_odp_table_path, logger)
    if not cds_view_exists and not odp_view_exists:
        logger.error(f"Table {p_CDSViewName} not found or invalid at path '{complete_table_path}'")
        logger.error(f"Fallback Table {p_ODPName} not found or invalid at path '{complete_odp_table_path}'")
        logger.save_logs(spark=spark)
        raise DeltaTableNotFoundException(f"{complete_table_path} or {complete_odp_table_path}")

def validate_duplicate_primary_keys(
    spark: SparkSession,
    table_path: str,
    p_CDSViewName: str,
    df: DataFrame,
    primary_key_columns: list,
    logger: DataFrameLogger) -> None:
    """
    Validate that there are no duplicate entries for the given primary key columns.

    Checks for duplicate rows by grouping on the provided primary key columns plus
    the Key column, then identifying groups with count > 1.

    Parameters:
    :param spark: SparkSession
    :param table_path: Base path to the Delta table
    :param p_CDSViewName: CDS view name appended to the base path
    :param df: DataFrame to validate
    :param primary_key_columns: List of column names that form the primary key
    :param logger: Logger object for logging

    Raises:
    :raises ValueError: If primary_key_columns is empty
    :raises DuplicateEntriesInTable: If duplicate entries are found
    """
    try:
        complete_table_path = table_path + p_CDSViewName
        # Validate that primary key columns are provided
        if not primary_key_columns or len(primary_key_columns) == 0:
            error_msg = "Primary key columns list cannot be empty"
            logger.error(error_msg)
            logger.save_logs(spark=spark)
            raise ValueError(error_msg)

        logger.info(f"Validating for duplicate entries in table '{p_CDSViewName}' with primary keys: {primary_key_columns}")

        # Check if duplicates exist
        duplicates = df.groupBy(primary_key_columns + ["Key"]).count().filter(F.col("count") > 1)

        if duplicates.count() > 0:
            # Get the specific duplicate key values
            duplicate_keys_df = duplicates.select(*primary_key_columns).distinct()
            duplicate_keys = [row.asDict() for row in duplicate_keys_df.collect()]

            error_msg = f"Duplicate entries found in table '{p_CDSViewName}' at path {complete_table_path} for " +\
                        f"primary key columns: {primary_key_columns}. Duplicate keys: {duplicate_keys}"

            logger.error(error_msg)
            logger.save_logs(spark=spark)
            raise DuplicateEntriesInTable(complete_table_path, primary_key_columns)

        logger.info(f"No duplicate entries found in table '{p_CDSViewName}'")

    except DuplicateEntriesInTable:
        raise
    except ValueError:
        raise
    except Exception as exception:
        logger.error(f"Exception occurred during duplicate key validation: {str(exception)}")
        logger.save_logs(spark=spark)
        raise

def validate_watermark_columns(
    spark: SparkSession,
    table_path: str,
    p_CDSViewName: str,
    df: DataFrame,
    isDeltaTable: bool,
    logger: DataFrameLogger) -> None:
    """
    Validate that all required watermark columns are present in the table.

    Checks for required watermark columns in the provided DataFrame.
    Always requires _UpdateTimeStamp and _SystemName.
    Requires _Delete only when isDeltaTable is True.

    Parameters:
    :param spark: SparkSession
    :param table_path: Base path to the Delta table
    :param p_CDSViewName: CDS view name appended to the base path
    :param df: DataFrame to validate
    :param isDeltaTable: Boolean indicating if the table is a Delta table
    :param logger: Logger object for logging

    Raises:
    :raises WaterMarkColumnsNotFound: If any required watermark columns are missing
    """
    try:
        complete_table_path = table_path + p_CDSViewName
        required_watermark_columns = ['_UpdateTimeStamp', '_SystemName']
        if isDeltaTable:
            required_watermark_columns.append('_Delete')

        logger.info(f"Validating watermark columns in table '{p_CDSViewName}'")
        existing_columns = set(df.columns)

        # Check for missing columns
        missing_columns = [col for col in required_watermark_columns if col not in existing_columns]

        if missing_columns:
            error_msg = f"Required watermark columns not found in table '{p_CDSViewName}' at " + \
                        f"path {complete_table_path}. Missing columns: {missing_columns}"
            logger.error(error_msg)
            logger.save_logs(spark=spark)
            raise WaterMarkColumnsNotFound(complete_table_path, missing_columns)

        logger.info(f"All required watermark columns are present in table '{p_CDSViewName}'")

    except WaterMarkColumnsNotFound:
        raise
    except Exception as exception:
        logger.error(f"Exception occurred during watermark columns validation: {str(exception)}")
        raise

def validate_record_count_match(
    spark: SparkSession,
    p_CDSViewName:str,
    table_path_1: str,
    table_path_2: str,
    logger: DataFrameLogger) -> None:
    """
    Validate that record counts match between two Delta tables.

    Compares the number of rows in two tables at different paths. Both paths must be
    valid Delta tables. Raises an exception if the counts do not match exactly.

    Parameters:
    :param spark: SparkSession
    :param p_CDSViewName: Name of the CDS View.
    :param table_path_1: Base path to the first Delta table
    :param table_path_2: Base path to the second Delta table
    :param logger: Logger object for logging

    Raises:
    :raises DeltaTableNotFoundException: If either table path is not a valid Delta table
    :raises RecordCountMismatchException: If record counts do not match
    """
    try:

        tb1_complete_path = table_path_1 + p_CDSViewName
        tb2_complete_path = table_path_2 + p_CDSViewName
        logger.info(f"Validating record count match between '{tb1_complete_path}' and '{tb2_complete_path}'")

        # Validate both tables exist and are Delta tables
        validate_delta_table(
            spark=spark,
            table_path=table_path_1,
            p_CDSViewName=p_CDSViewName,
            logger=logger
        )

        validate_delta_table(
            spark=spark,
            table_path=table_path_2,
            p_CDSViewName=p_CDSViewName,
            logger=logger
        )

        # Read both tables and count records
        logger.info(f"Loading Data from {tb1_complete_path}")
        dt_1 = DeltaTable.forPath(spark, tb1_complete_path)
        df_1 = dt_1.toDF()
        if "Key" in df_1.columns:
            df_1 = df_1.filter(col("Key") != "-1")

        logger.info(f"Loading Data from {tb2_complete_path}")
        dt_2 = DeltaTable.forPath(spark, tb2_complete_path)
        df_2 = dt_2.toDF()
        if "Key" in df_2.columns:
            df_2 = df_2.filter(col("Key") != "-1")

        logger.info(f"Getting row count from both tables.")
        count_1 = df_1.count()
        count_2 = df_2.count()

        logger.info(f"Record count for table 1 : {count_1} at path - {table_path_1}")
        logger.info(f"Record count for table 2 : {count_2} at path - {table_path_2}")

        if count_1 != count_2:
            error_msg = f"Record count mismatch. Path 1 ('{table_path_1}'): {count_1} rows, Path 2 ('{table_path_2}'): {count_2} rows"
            logger.error(error_msg)
            logger.save_logs(spark=spark)
            raise RecordCountMismatchException(tb1_complete_path, count_1, tb2_complete_path, count_2)

        logger.info(f"Record counts match: {count_1} rows in both tables")

    except (DeltaTableNotFoundException, RecordCountMismatchException):
        raise
    except Exception as exception:
        logger.error(f"Exception occurred during record count validation: {str(exception)}")
        raise

def validate_required_params(**params):
    """Validate that required parameters are not None or empty strings."""
    for param_name, param_value in params.items():
        if param_value is None or (isinstance(param_value, str) and len(param_value) == 0):
            raise ValueError(f"Parameter '{param_name}' is required and cannot be empty.")

def validate_cube_config(
    spark: SparkSession,
    p_CDSViewName: str,
    p_cubeConfig: list,
    p_silver_tables_path: str,
    p_gold_tables_path: str,
    logger: DataFrameLogger,
):
    if isinstance(p_cubeConfig, str):
        try:
            p_cubeConfig = json.loads(p_cubeConfig)
        except json.JSONDecodeError as exception:
            raise ValueError("Invalid p_cubeConfig JSON format.") from exception

    if not isinstance(p_cubeConfig, list):
        raise ValueError("p_cubeConfig must be a list or a JSON string representing a list.")

    error_messages = []
    required_fact_columns = set()
    for config in p_cubeConfig:
        if not isinstance(config, dict):
            raise ValueError("Each cube config entry must be a dictionary.")

        dimension_table = config["DimensionTable"]
        join_conditions = ast.literal_eval(config["JoinCondition"])
        join_order = config['JoinOrder']
        complete_table_path = p_gold_tables_path + dimension_table

        # extract required dimension columns from join conditions.
        required_dimension_columns = []
        for condition in join_conditions:
            column_name = condition[1]
            fact_column = condition[0]
            required_dimension_columns.append(column_name)

            # only validate fact columns for the first join in the order
            # as subsequent columns might not have been copied to the fact table.
            if join_order == 0:
                required_fact_columns.add(fact_column)

        logger.info(f"Checking if the required dimension table {dimension_table} exists in Gold Lakehouse.")
        if not check_if_table_exists(spark, complete_table_path, logger):
            err = f"❎ - Table {dimension_table} not found or invalid at path '{complete_table_path}'"
            logger.error(err)
            error_messages.append(err)
            continue

        # Read both tables and count records
        column_set = set(spark.read.format("delta").load(complete_table_path).columns)
        required_dimension_columns.extend(["Key", "_SystemName"])

        logger.info(f"Checking columns {required_dimension_columns} in dimension table {dimension_table} from join condition.")
        for req_column in set(required_dimension_columns):
            if req_column not in column_set:
                err = f"❎ - Required column {req_column} for join not found in table {dimension_table}. " + \
                        "Please check and verify join condition or check the column in your source table."
                logger.error(err)
                error_messages.append(err)

    logger.info(f"Starting required column validation for fact table {p_CDSViewName}")
    complete_table_path = p_silver_tables_path + p_CDSViewName

    if not check_if_table_exists(spark, complete_table_path, logger):
        err = f"❎ - Table {p_CDSViewName} not found or invalid at path '{complete_table_path}'"
        logger.error(err)
        error_messages.append(err)
    else:
        column_set = set(spark.read.format("delta").load(complete_table_path).columns)
        for req_column in required_fact_columns:
            if req_column not in column_set:
                err = f"❎ - Required column {req_column} for join not found in table {p_CDSViewName}. "
                logger.error(err)
                error_messages.append(err)

    logger.info(f"Completed required column validation for fact table {p_CDSViewName}")

    if len(error_messages) > 0:
        logger.save_logs(spark=spark)
        raise CubeConfigValidationFailed(error_messages)

def get_null_safe_join_condition(
    df_left: DataFrame,
    df_right: DataFrame,
    key_columns: list
) -> Column:
    """
    Build a null-safe equality join condition for two DataFrames.

    Null values are considered equal when both DataFrames contain null for the
    same key column.

    Args:
        df_left: Left DataFrame.
        df_right: Right DataFrame.
        key_columns: Column names shared by both DataFrames.

    Returns:
        Combined Spark join condition.

    Raises:
        ValueError: If no key columns are supplied or a key column is missing.
    """
    if not key_columns:
        raise ValueError("At least one join key column must be provided.")

    missing_left = [name for name in key_columns if name not in df_left.columns]
    missing_right = [name for name in key_columns if name not in df_right.columns]

    if missing_left or missing_right:
        raise ValueError(
            "Join columns are missing. "
            f"Left DataFrame: {missing_left}; Right DataFrame: {missing_right}."
        )

    return reduce(
        lambda condition, next_condition: condition & next_condition,
        (
            df_left[column_name].eqNullSafe(df_right[column_name])
            for column_name in key_columns
        )
    )