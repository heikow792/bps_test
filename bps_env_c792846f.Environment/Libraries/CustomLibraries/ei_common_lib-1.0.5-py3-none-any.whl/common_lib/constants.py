"""_summary_:
This file contains constants used in the project.
"""
# folder where the log files are stored
LOG_FILE_PATH = 'Files/Logs/'

# Stage constants for medallion architecture
STAGE_B2S = 'B2S'
STAGE_S2G = 'S2G'

# Log type constants
LOG_TYPE_LOG = 'LOG'
LOG_TYPE_METRIC = 'METRIC'

# Runtime context properties to capture from notebookutils.runtime.context
CONTEXT_PROPERTIES = [
    'currentNotebookName',
    'currentNotebookId',
    'rootNotebookName',
    'currentWorkspaceName',
    'currentWorkspaceId',
    'defaultLakehouseName',
    'environmentId',
    'isForPipeline',
    'isForInteractive',
    'isReferenceRun'
]

# Default log columns for DataFrameLogger
DEFAULT_LOG_COLUMNS = [
    'guid',
    'level',
    'precise_timestamp',
    'view_name',
    'message',
    'log_type',
    'stage',
    'systemName',
    'currentNotebookName',
    'currentNotebookId',
    'rootNotebookName',
    'currentWorkspaceName',
    'currentWorkspaceId',
    'defaultLakehouseName',
    'environmentId',
    'isForPipeline',
    'isForInteractive',
    'isReferenceRun'
]

# column name for delete flag
DELETE_COLUMN = '_Delete'

FABRIC_SQL_CONNECTION_STRING_TEMPLATE = (
    "Driver={{ODBC Driver 18 for SQL Server}};"
    "Server={sql_endpoint};"
    "Database={full_db_name};"
    "Encrypt=Yes;"
    "TrustServerCertificate=No"
)

CDS_VIEW_TO_TIMESTAMP_COLUMN_MAP = {
    "C_SALESDOCUMENTITEMDEX_1": "SALESDOCUMENTDATE",
    "C_BILLINGDOCITEMBASICDEX_1": "BILLINGDOCUMENTDATE",
    "C_PURCHASEORDERDEX": "CREATIONDATE",
    "C_PURCHASEORDERITEMDEX": "PURCHASEORDERDATE",
    "C_SUPPLIERINVOICEDEX": "DOCUMENTDATE",
    "C_SUPPLIERINVOICEITEMDEX": "DOCUMENTDATE",
    "I_OPERATIONALACCTGDOCITEM": "POSTINGDATE"
}