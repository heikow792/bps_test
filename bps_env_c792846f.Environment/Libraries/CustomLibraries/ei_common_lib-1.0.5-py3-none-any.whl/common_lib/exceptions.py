# common exceptions

class BPSException(Exception):
    """BPS Base Exception class.
    """

    MESSAGE = None
    CODE = None
    ERROR_CATEGORY = None
    RECOMMENDED_ACTION = ""

    def __init__(self, message=None) -> None:
        self.message = message or self.MESSAGE
        super().__init__(self.message, self.CODE)

    def __str__(self):
        msg = self.message or self.MESSAGE
        return f"[{self.CODE}] - {msg}\nRecommended Action: {self.RECOMMENDED_ACTION}"

class LakehouseNotFoundException(BPSException):
    def __init__(self, lakehouse_name, workspace_id):
        self.lakehouse_name = lakehouse_name
        self.workspace_id = workspace_id
        self.MESSAGE = f"Lakehouse {lakehouse_name} not found in workspace {workspace_id}."
        self.CODE = "Lakehouse_Not_Found"
        self.ERROR_CATEGORY = "ClientError"
        self.RECOMMENDED_ACTION = f"Please check if the lakehouse {lakehouse_name} is correct and exists in the specified workspace {workspace_id}."

        super().__init__(self.MESSAGE)

class MirroredDatabaseNotFoundException(BPSException):
    def __init__(self, database_name, workspace_id):
        self.database_name = database_name
        self.workspace_id = workspace_id
        self.MESSAGE = f"Mirrored Database {database_name} not found in workspace {workspace_id}."
        self.CODE = "Mirrored_Database_Not_Found"
        self.ERROR_CATEGORY = "ClientError"
        self.RECOMMENDED_ACTION = f"Please check if the Mirrored Database {database_name} is correct and exists in the specified workspace {workspace_id}."

        super().__init__(self.MESSAGE)

class NotADeltaTableException(BPSException):
    def __init__(self, table_path):
        self.table_path = table_path
        self.MESSAGE = f"Path '{table_path}' is not a valid Delta table."
        self.CODE = "Not_A_Delta_Table"
        self.ERROR_CATEGORY = "ValidationError"
        self.RECOMMENDED_ACTION = f"Please verify that '{table_path}' points to a valid Delta table."

        super().__init__(self.MESSAGE)

class DeltaTableNotFoundException(BPSException):
    def __init__(self, table_path):
        self.table_path = table_path
        self.MESSAGE = f"Delta table not found at path '{table_path}'."
        self.CODE = "Delta_Table_Not_Found"
        self.ERROR_CATEGORY = "ValidationError"
        self.RECOMMENDED_ACTION = f"Please verify that the table path '{table_path}' exists and is accessible."

        super().__init__(self.MESSAGE)

class DuplicateEntriesInTable(BPSException):
    def __init__(self, table_path, primary_key_columns):
        self.table_path = table_path
        self.primary_key_columns = primary_key_columns
        self.MESSAGE = f"Duplicate entries found in table '{table_path}' for primary key columns: {primary_key_columns}."
        self.CODE = "Duplicate_Entries_In_Table"
        self.ERROR_CATEGORY = "DataIntegrityError"
        self.RECOMMENDED_ACTION = f"Please investigate and resolve duplicate entries in the primary key columns: {primary_key_columns}."

        super().__init__(self.MESSAGE)

class WaterMarkColumnsNotFound(BPSException):
    def __init__(self, table_path, missing_columns):
        self.table_path = table_path
        self.missing_columns = missing_columns
        self.MESSAGE = f"Required watermark columns not found in table '{table_path}'. Missing columns: {missing_columns}."
        self.CODE = "Watermark_Columns_Not_Found"
        self.ERROR_CATEGORY = "SchemaValidationError"
        self.RECOMMENDED_ACTION = f"Please ensure all required watermark columns ({missing_columns}) are present in the table schema."

        super().__init__(self.MESSAGE)

class RecordCountMismatchException(BPSException):
    def __init__(self, table_path_1, count_1, table_path_2, count_2):
        self.table_path_1 = table_path_1
        self.count_1 = count_1
        self.table_path_2 = table_path_2
        self.count_2 = count_2
        self.MESSAGE = f"Record count mismatch between tables. Path 1 ('{table_path_1}'): {count_1} rows, Path 2 ('{table_path_2}'): {count_2} rows."
        self.CODE = "Record_Count_Mismatch"
        self.ERROR_CATEGORY = "DataConsistencyError"
        self.RECOMMENDED_ACTION = f"Please investigate the data consistency between '{table_path_1}' and '{table_path_2}'."

        super().__init__(self.MESSAGE)

class CubeConfigValidationFailed(BPSException):
    def __init__(self, validation_errors):
        self.validation_errors = validation_errors
        self.MESSAGE = "Cube config validation failed. " + " | ".join(validation_errors)
        self.CODE = "Cube_Config_Validation_Failed"
        self.ERROR_CATEGORY = "SchemaValidationError"
        self.RECOMMENDED_ACTION = "Please verify the relationships in Business Process Solutions. Check the columns and tables used in relationships. If table is not available from source system, remove it from the dataset and relationships." + \
        "If the columns is missing from the table, please check the join conditions in Manage Relationships in BPS and make sure the columns are included in the source table."

        super().__init__(self.MESSAGE)

class FabricSqlDatabaseNotFoundException(BPSException):
    def __init__(self, database_name, workspace_id):
        self.database_name = database_name
        self.workspace_id = workspace_id
        self.MESSAGE = f"Fabric SQL Database {database_name} not found in workspace {workspace_id}."
        self.CODE = "Fabric_SQL_Database_Not_Found"
        self.ERROR_CATEGORY = "ClientError"
        self.RECOMMENDED_ACTION = f"Please check if the Fabric SQL Database {database_name} is correct and exists in the specified workspace {workspace_id}."

        super().__init__(self.MESSAGE)
