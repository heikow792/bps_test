"""
    _summary_: This file defines a concrete implementation of LoggerInterface.
"""

from datetime import datetime
from typing import Optional, List, Dict, Union, Any
import pandas as pd
from pyspark.sql import SparkSession, DataFrame as SparkDataFrame
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DecimalType, FloatType


class DataFrameLogger():
    """
    DataFrameLogger is a concrete implementation of LoggerInterface.

    Parameters:
    - log_file_path (str): Path where log files will be stored.
    - prefix (str): Prefix/identifier for the view being processed.
    - guid (str, optional): A GUID to associate with log entries.
    - stage (str, optional): Processing stage (e.g., 'B2S', 'S2G').
    - runtime_context (Any, optional): Runtime context object from notebookutils.runtime.context.
    - log_columns (list, optional): List of column names for the log DataFrame.
    - schema (StructType, optional): Custom schema for the log DataFrame.
    """
    def __init__(
        self,
        log_file_path: str,
        prefix: str,
        guid: Optional[str] = None,
        stage: Optional[str] = None,
        runtime_context: Optional[Any] = None,
        log_columns: Optional[List[str]] = None,
        schema: Optional[StructType] = None,
        system_name: Optional[str] = None
    ) -> None:
        from common_lib.constants import DEFAULT_LOG_COLUMNS, CONTEXT_PROPERTIES

        if log_columns is None:
            log_columns = DEFAULT_LOG_COLUMNS

        if schema is None:
            # Auto-generate schema with StringType for all columns
            self.schema = StructType([
                StructField(col, StringType(), True) for col in log_columns
            ])
        else:
            self.schema = schema

        self.log_file_path = log_file_path
        self.log_columns = log_columns

        # Use lists for better performance instead of DataFrames
        self.log_buffer: List[Dict[str, str]] = []
        self.all_session_logs_buffer: List[Dict[str, str]] = []

        # Initialize empty DataFrames
        self.log_df = pd.DataFrame(columns=log_columns)
        self.all_session_logs = pd.DataFrame(columns=log_columns)

        self.guid = guid
        self.prefix = prefix
        self.stage = stage
        self.system_name = system_name
        self.start_time = self.get_precise_timestamp()

        # Extract runtime context properties
        self.context_values = {}
        if runtime_context is not None:
            for prop in CONTEXT_PROPERTIES:
                value = None
                if prop in runtime_context:
                    value = runtime_context[prop]
                # Convert to string, keeping None as None
                self.context_values[prop] = str(value) if value is not None else None
        else:
            # If no context provided, set all to None
            for prop in CONTEXT_PROPERTIES:
                self.context_values[prop] = None

    def log(self, level: str, message: str) -> None:
        """
        Log a message with the specified severity level.

        Parameters:
        - level (str): The severity level of the log message.
        - message (str): The log message.

        Returns:
        None
        """
        from common_lib.constants import LOG_TYPE_LOG

        try:
            log_entry = {
                'guid': self.guid,
                'level': level.upper(),  # Normalize level to uppercase
                'precise_timestamp': self.get_precise_timestamp(),
                'view_name': self.prefix,
                'message': str(message),  # Ensure message is string
                'log_type': LOG_TYPE_LOG,
                'stage': self.stage,
                'systemName': self.system_name
            }

            # Add runtime context values
            log_entry.update(self.context_values)

            # Add the log entry to the log buffer
            self.log_buffer.append(log_entry)

            # Add the log entry to the all session logs buffer
            self.all_session_logs_buffer.append(log_entry)

        except Exception as e:
            # If logging fails, at least print the error
            print(f"ERROR: Failed to log message: {str(e)}")
            print(f"Original message: {level} - {message}")

    def log_metric(self, metric_data: str) -> None:
        """
        Log a metric entry with level='METRIC' and log_type='METRIC'.

        Parameters:
        - metric_data (str): The metric data, typically formatted as 'METRIC_NAME | VALUE'.

        Returns:
        None
        """
        from common_lib.constants import LOG_TYPE_METRIC

        try:
            log_entry = {
                'guid': self.guid,
                'level': 'METRIC',
                'precise_timestamp': self.get_precise_timestamp(),
                'view_name': self.prefix,
                'message': str(metric_data),
                'log_type': LOG_TYPE_METRIC,
                'stage': self.stage,
                'systemName': self.system_name
            }

            # Add runtime context values
            log_entry.update(self.context_values)

            # Add the log entry to the log buffer
            self.log_buffer.append(log_entry)

            # Add the log entry to the all session logs buffer
            self.all_session_logs_buffer.append(log_entry)

        except Exception as e:
            # If logging fails, at least print the error
            print(f"ERROR: Failed to log metric: {str(e)}")
            print(f"Original metric_data: {metric_data}")

    @staticmethod
    def get_precise_timestamp() -> str:
        """
        Get the current precise timestamp.

        Returns:
        str: The current precise timestamp in the format 'YYYY-MM-DD HH:MM:SS.mmmmmm'.
        """
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

    # Log entries accumulate in lists during normal operation
    # Conversion to DataFrame happens only when needed (save, export)
    # This approach can be 10-100x faster for applications that generate many log entries, 
    # especially in tight loops or high-frequency logging scenarios.
    def flush_buffers_to_dataframes(self) -> None:
        """
        Flush log buffers to DataFrames. This should be called before any DataFrame operations.
        """
        if self.log_buffer:
            self.log_df = pd.DataFrame(self.log_buffer, columns=self.log_columns)
            self.log_buffer.clear()

        if self.all_session_logs_buffer:
            self.all_session_logs = pd.DataFrame(self.all_session_logs_buffer, columns=self.log_columns)
            # Note: We don't clear all_session_logs_buffer as it accumulates across sessions

    def save_logs(self, spark: SparkSession, log_duration: bool = False) -> None:
        """
        Save the current session logs to the Delta Lakehouse.

        Parameters:
        - spark (SparkSession): The PySpark SparkSession.

        Returns:
        None

        Raises:
        - Exception: If there's an error saving logs to Delta Lakehouse.
        """
        try:
            if log_duration:
                end_time = self.get_precise_timestamp()
                # log duration in seconds
                # convert string to datetime object
                end_time = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S.%f')
                start_time = datetime.strptime(self.start_time, '%Y-%m-%d %H:%M:%S.%f')
                self.log('INFO', f"Duration for {self.prefix} = {end_time - start_time}")

            # Flush buffers to DataFrames before saving
            self.flush_buffers_to_dataframes()

            if not self.log_df.empty:
                spark_df = self.to_spark_dataframe(spark)

                if spark_df is not None:
                    (
                        spark_df.write
                        .format('delta')
                        .mode('append')
                        # Allow adding new columns when DEFAULT_LOG_COLUMNS expands over time
                        .option('mergeSchema', 'true')
                        .save(self.log_file_path)
                    )
                    print(f"Successfully saved {len(self.log_df)} logs to Delta Lakehouse at {self.log_file_path}")
                    print()
                else:
                    print("Failed to convert logs to Spark DataFrame")
            else:
                print("No logs to save for this session.")

        except ValueError as e:
            print(f"Error parsing timestamps: {str(e)}")
            raise
        except Exception as e:
            print(f"Error saving logs to Delta Lakehouse: {str(e)}")
            # Log the error before raising
            self.log('ERROR', f"Failed to save logs: {str(e)}")
            raise
        finally:
            # Reset log DataFrame and buffer for next session
            self.log_df = pd.DataFrame(columns=self.log_columns)
            self.log_buffer.clear()

    def pandas_to_spark_type(self, pandas_type: str) -> Union[IntegerType, FloatType, StringType, DecimalType]:
        """
        Converts a pandas data type to a Spark data type.

        Parameters:
        pandas_type (str): The pandas data type to convert.

        Returns:
        Spark data type: The corresponding Spark data type.
        """
        type_mapping = {
            'int64': IntegerType(),
            'float64': FloatType(),
            'object': StringType(),
            'double': DecimalType()
        }
        return type_mapping.get(str(pandas_type), StringType())

    def get_schema_from_pandas_df(self, dataframe) -> StructType:
        """
        Generates a Spark schema from a Pandas DataFrame.

        Parameters:
        dataframe (DataFrame): The Pandas DataFrame to generate a schema from.

        Returns:
        StructType: The generated Spark schema.
        """
        spark_schema = StructType()
        for column in dataframe.columns:
            spark_schema.add(StructField(column, self.pandas_to_spark_type(dataframe[column].dtype), True))
        return spark_schema

    def info(self, message: str):
        """
        Log an informational message.

        Parameters:
        - message (str): The log message.

        Returns:
        None
        """
        print(message)
        self.log('INFO', message)

    def warning(self, message: str):
        """
        Log a warning message.

        Parameters:
        - message (str): The log message.

        Returns:
        None
        """
        print(message)
        self.log('WARNING', message)

    def error(self, message):
        """
        Log an error message.

        Parameters:
        - message (str): The log message.

        Returns:
        None
        """
        print(message)
        self.log('ERROR', message)

    def debug(self, message: str):
        """
        Log a debug message.

        Parameters:
        - message (str): The log message.

        Returns:
        None
        """
        self.log('DEBUG', message)

    def exception(self, message: str):
        """
        Log an exception message, trimming it to a specific length.

        Parameters:
        - message (str): The exception message.

        Returns:
        None
        """
        trimmed_message = self.trim_exception_message(message)
        print(trimmed_message)
        self.log('EXCEPTION', trimmed_message)

    def trim_exception_message(self, message: str) -> str:
        """
        Trim the exception message to a specific length.

        Parameters:
        - message (str): The exception message.

        Returns:
        str: The trimmed exception message.
        """
        max_message_length = 1000
        return message[:max_message_length] if len(message) > max_message_length else message

    def to_spark_dataframe(self, spark: SparkSession) -> Optional[SparkDataFrame]:
        """
        Convert the current session log DataFrame to a Spark DataFrame.

        Parameters:
        - spark (SparkSession): The PySpark SparkSession.

        Returns:
        pyspark.sql.DataFrame or None: The Spark DataFrame or None if the log DataFrame is empty.
        """
        # Ensure buffers are flushed to DataFrames
        self.flush_buffers_to_dataframes()

        if not self.log_df.empty:
            spark_df = spark.createDataFrame(self.log_df, schema=self.schema)
            return spark_df
        else:
            print("No logs for this session.")
            return None

    def get_all_session_logs(self, spark: SparkSession) -> Optional[SparkDataFrame]:
        """
        Convert all session log DataFrame to a Spark DataFrame.

        Parameters:
        - spark (SparkSession): The PySpark SparkSession.

        Returns:
        pyspark.sql.DataFrame or None: The Spark DataFrame or None if the log DataFrame is empty.
        """
        # Ensure buffers are flushed to DataFrames
        self.flush_buffers_to_dataframes()

        if not self.all_session_logs.empty:
            return spark.createDataFrame(self.all_session_logs, schema=self.schema)
        else:
            print("No logs for all sessions.")
            return None

    def set_system_name(self, system_name: str):
        # function to set function name is not set during initialization of logger.
        self.system_name = system_name