'''
Description: This file contains the Data type mapping between SAP and python used in notebooks.
'''

from pyspark.sql.types import StringType, DateType, IntegerType, DecimalType


# Define the mapping
sap_data_type_mapping = {
    'CHAR': StringType(),
    'CUKY': StringType(),
    'DATS': DateType(),
    'TIMS': StringType(),
    'NUMC': IntegerType(),
    'QUAN': DecimalType(),
    'UNIT': StringType(),
    'DEC': DecimalType(),
    'CURR': DecimalType(),
    'LANG': StringType()
}