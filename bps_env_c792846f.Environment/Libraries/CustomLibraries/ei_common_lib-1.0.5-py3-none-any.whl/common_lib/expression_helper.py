from pyspark.sql import DataFrame

from common_lib.constants import DELETE_COLUMN


def get_update_expressions(
    dataframe: DataFrame,
    excluded_columns: set,
    df_alias: str):
    """
    Generates a dictionary of update expressions for a DataFrame.

    Args:
        dataframe (DataFrame): The DataFrame for which to generate update expressions.
        excluded_columns (list): A list of column names to exclude from the update expressions.

    Returns:
        dict: A dictionary where the keys are column names and the values are update expressions.
    """
    update_expressions = {}
    for col in dataframe.columns:
        if col not in excluded_columns and col != DELETE_COLUMN:
            update_expressions[col] = f"{df_alias}.{col}"
    return update_expressions

def get_insert_expressions(
    dataframe: DataFrame,
    df_alias: str):
    """
    Generates a dictionary of insert expressions for a DataFrame.

    Args:
        df (DataFrame): The DataFrame for which to generate insert expressions.

    Returns:
        dict: A dictionary where the keys are column names and the values are insert expressions.
    """
    insert_expressions = {}
    for col in dataframe.columns:
        if col != DELETE_COLUMN:
            insert_expressions[col] = f"{df_alias}.{col}"
    return insert_expressions

def get_merge_condition(
    merge_keys: list,
    right_alias: str,
    left_alias: str):
    """
    Generates a merge condition string for a DataFrame merge operation.

    This function iterates over the primary key fields array and for each primary key, it appends
    a string to the merge condition in the format "{gold_dim_alias}.{pk} = {silver_dim_alias}.{pk}".
    If the merge condition is not empty, it prepends ' AND ' to the string.

    Args:
        merge_keys (list): A list of primary key field names.
        silver_dim_alias (str): The alias for the silver dimension DataFrame.
        gold_dim_alias (str): The alias for the gold dimension DataFrame.

    Returns:
        str: The merge condition string.
    """
    merge_condition = ''
    for pk in merge_keys:
        if merge_condition != '':
            merge_condition += ' AND '
        merge_condition += f"{left_alias}.{pk} = {right_alias}.{pk}"
    return merge_condition
